'use strict';

module.exports = {
    awsAccountId: '578641730378',
    queue:'https://sqs.us-east-1.amazonaws.com/578641730378/testSQS',
    phone: '+37493802210'
};


